data = "let the force be with you"
print(data.upper())
print(data.title())
print(data.capitalize())


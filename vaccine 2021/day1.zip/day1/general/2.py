# multi assignment

x = y = z = 100

a, b, c = 100, "force", 23.45

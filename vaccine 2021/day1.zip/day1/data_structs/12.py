# sets
# operations


dc = {'batman', 'wonder woman', 'aquaman', 'flash'}

avengers = {'iron man', 'captain', 'black widow', 'thor', 'hulk', 'aquaman',
            'hulk', 'captain', 'flash'}

print(avengers)

print(avengers | dc)
print(avengers & dc)
print(avengers - dc)
print(avengers ^ dc)

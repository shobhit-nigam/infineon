# immutable
fame = "covid 19"
popular = 'corona'

print(fame.upper())
print(fame)

fame = "cOvid 19"

#error prone:
fame[1] = 'O'

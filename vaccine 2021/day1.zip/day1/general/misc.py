#!/usr/bin/env python
# coding: utf-8

# In[1]:


int("334")


# In[2]:


int(54.67)


# In[3]:


lista = ['qq', 'tt', 'dd', 'yy', 'ss', 'qq', 'ff', 'dd']


# In[5]:


tuple(lista)


# In[6]:


ta = tuple(lista)


# In[7]:


type(lista)


# In[8]:


type(ta)


# In[9]:


lista = tuple(lista)


# In[10]:


set(lista)


# In[11]:


country = 'india'


# In[12]:


list(country)


# In[13]:


avengers = {'captain':'sheild', 'ironman':'suit'}


# In[14]:


avengers.items()


# In[15]:


list(avengers.items())


# In[16]:


x = input()


# In[17]:


print(x)


# In[18]:


varx = input()


# In[19]:


print(varx)


# In[20]:


varx


# In[21]:


type(varx)


# In[ ]:





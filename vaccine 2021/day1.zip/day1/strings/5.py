# immutable
fame = "covid 19"
fame_2 = fame
popular = 'corona'

print(fame)
print(fame_2)

fame = "cOvid 19"

print(fame)
print(fame_2)

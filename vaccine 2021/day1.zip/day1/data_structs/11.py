# sets
# no duplicates


dc = ('batman', 'wonder woman', 'aquaman', 'flash')

avengers = {'iron man', 'captain', 'black widow', 'thor', 'hulk', 'aquaman',
            'hulk', 'captain', 'flash'}

print(avengers)
print(type(avengers))

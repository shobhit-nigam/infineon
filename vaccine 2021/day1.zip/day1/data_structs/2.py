# lists
# slicing

lista = ['let', 'the', 'force', 'be', 'with', 'you']
listb = [4, 7, 9, 10, 23, 4, 8, 13]

print(lista)
print(type(lista))

print(lista[:10:3])

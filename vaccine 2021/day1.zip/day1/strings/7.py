data = "let the force be with you"
print(data.replace('force', 'energy'))
print(data)

data = data.replace('force', 'energy')
print(data)

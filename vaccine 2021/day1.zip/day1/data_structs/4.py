# lists
# mutable add data


lista = ['let', 'the', 'force', 'be', 'with', 'you']
listb = [4, 7, 9, 10, 23, 4, 8, 13]

lista.append("and me")
print(lista)
lista.insert(2, "major")
print(lista)

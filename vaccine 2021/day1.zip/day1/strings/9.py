# functions
data = "let the force be with you"

print(data.index('e'))


print(data.rindex('e'))

print(data.split())

print(data.split("t"))

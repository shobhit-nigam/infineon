print("hello")

def red():
    print("scarlet red")
    
dataa = 23
datab = 33
lista = [2, 4, 6, 1]

def orange():
    print("colour or fruit")
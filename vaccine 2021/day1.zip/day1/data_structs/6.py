# lists
# functions


lista = ['let', 'the', 'force', 'be', 'with', 'you']
listb = [4, 7, 9, 10, 23, 4, 8, 13]

listc = ["and", "me"]
print(lista)
lista.append(listc)
print(lista)

lista = ['let', 'the', 'force', 'be', 'with', 'you']
lista.extend(listc)
print(lista)

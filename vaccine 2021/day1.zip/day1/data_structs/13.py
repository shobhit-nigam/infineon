# dict
# operations


dc = {'batman', 'wonder woman', 'aquaman', 'flash'}

avengers = {'iron man':'suit', 'captain':'shield',
            'black widow':'energy', 'thor':'hammer', 'hulk':'smash'}

print(avengers)

print(avengers['thor'])


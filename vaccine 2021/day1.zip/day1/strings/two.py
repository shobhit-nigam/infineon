# immutable
fame = "covid 19"
popular = 'corona'

print(fame.upper())
print(fame)

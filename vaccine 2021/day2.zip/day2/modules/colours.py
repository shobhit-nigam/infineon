def blue():
    print("cool blue")
    
def yellow():
    print("bright yellow")
    
    
def green():
    print("mixture of ")
    blue()
    yellow()
    
def red():
    print("in colours red")
# dict
# changing values
# adding key:value


dc = {'batman', 'wonder woman', 'aquaman', 'flash'}

avengers = {'iron man':'suit', 'captain':['shield', 'hammer'],
            'black widow':'energy', 'thor':'hammer', 'hulk':'smash'}

print(avengers)

print(avengers['captain'])

avengers['hulk'] = 'bulk'

avengers['hawkeye'] = 'arrows'

print(avengers)

avengers['captain'][0] = "rightousness"

print(avengers)

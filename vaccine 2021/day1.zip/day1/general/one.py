x = 20
print(x)
print(type(x))
